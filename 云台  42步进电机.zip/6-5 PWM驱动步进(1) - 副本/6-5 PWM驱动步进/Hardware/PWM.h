#ifndef __PWM_H
#define __PWM_H

void PWM_Init(void);
void PWM_SetCompare3(uint16_t Compare);
void PWM_SetCompare32(uint16_t Compare1);

#endif
