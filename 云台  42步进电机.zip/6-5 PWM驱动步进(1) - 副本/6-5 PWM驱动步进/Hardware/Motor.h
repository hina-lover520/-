#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Init(void);
void Motor_SetSpeed(int16_t Speed);
void Motor_SetSpeed2(int16_t Speed1);

void Step_PWM_SetCompare_X(double rs);
void Step_PWM_SetCompare_Y(double rs);
#endif
