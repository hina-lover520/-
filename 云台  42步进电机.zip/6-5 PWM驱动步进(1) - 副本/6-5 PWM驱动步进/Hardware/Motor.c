#include "stm32f10x.h"                  // Device header
#include "PWM.h"

/**
  * 函    数：直流电机初始化
  * 参    数：无
  * 返 回 值：无
  */
void Motor_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//开启GPIOA的时钟
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_7 | GPIO_Pin_5 | GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						//将PA4和PA5引脚初始化为推挽输出	
	
	GPIO_SetBits(GPIOA,GPIO_Pin_6);
	GPIO_SetBits(GPIOA,GPIO_Pin_7);//ENA引脚
	PWM_Init();													//初始化直流电机的底层PWM
}

/**
  * 函    数：直流电机设置速度
  * 参    数：Speed 要设置的速度，范围：-100~100
  * 返 回 值：无
  */

//GPIO_Pin_4是Y轴DIR
//GPIO_Pin_5是X轴DIR
void Motor_SetSpeed(int16_t Speed)
{
	if (Speed >= 0)							//如果设置正转的速度值
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_4);	//DIR置高电平
		PWM_SetCompare3(Speed);				//PWM设置为速度值     //   Y
	}
	else									//否则，即设置反转的速度值
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);	//PA4置低电平
		PWM_SetCompare3(-Speed);			//PWM设置为负的速度值，因为此时速度值为负数，而PWM只能给正数
	}
}
void Motor_SetSpeed2(int16_t Speed1)
	{
	if (Speed1 >= 0)							//如果设置正转的速度值
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_5);	//DIR置高电平
		PWM_SetCompare32(Speed1);				//PWM设置为速度值    //X
	}
	else									//否则，即设置反转的速度值
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_5);	//PA4置低电平
		PWM_SetCompare32(-Speed1);			//PWM设置为负的速度值，因为此时速度值为负数，而PWM只能给正数
	}
}

void Step_PWM_SetCompare_Y(double rs)      //设置转速
{
	double f =3200*rs;
	int cnt =(int)(1000000.0 / f);
	
	 TIM_SetAutoreload(TIM2, cnt);       //Y轴
	
	PWM_SetCompare3(cnt /2);
	
}

void Step_PWM_SetCompare_X(double rs)
{
	double f =3200*rs;
	int cnt =(int)(1000000.0 / f);
	
	 TIM_SetAutoreload(TIM3, cnt);   //X轴
	
	 PWM_SetCompare32(cnt /2);
}
