#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Motor.h"
#include "Key.h"
#include "LED.h"
#include "math.h"
#include "PWM.h"
#include "Timer.h"


#define  PI 3.1415936

uint8_t KeyNum;		//定义用于接收按键键码的变量
int8_t Speed;		//定义速度变量

uint8_t TimerErrorFlag;
uint16_t TimerCount;

int stage = 1;      // 从第一象限开始
int Count = 0;

int  period = 4;

double length = 0.50;  //水平长度
double height = 0.35;  //圆心高度

double circle_R =0.10;  //半径

double alpha;
 
double  side =0;
double W;   //角速度

double Motor_X_Speed  =0.0f ;
double Motor_Y_Speed  =0.0f ;

double one_four_t =0 ;    //转四分之一象限的时间
//int alpha1 = atan2( circle_R , side );

//double  side =sqrt((length *length) +(height*height));
int main(void)
{
	/*模块初始化*/
	OLED_Init();		//OLED初始化
	Motor_Init();		//直流电机初始化
	LED_Init();
	Timer_Init();
	PWM_Init();
	
//	Key_Init();			//按键初始化
	
	/*显示静态字符串*/
		//1行1列显示字符串Speed:
	
	side =sqrt((length *length) +(height*height));  //变
	
	alpha = asin( circle_R /side ) * 180 /PI;  //角度 
	
	W = 360 / period;
	
	one_four_t =(period /4 *1000);   //四分之一象限的时间
	
//	void Motor_Y_draw_rs_condition(void);
//	void Motor_X_draw_rs_condition(void);
//	Motor_SetSpeed(30);
//	Step_PWM_SetCompare_Y(1.0);
//	
//	Delay_ms(2000);
//	LED1_ON();
//	Delay_ms(2000);
//	LED1_OFF();
//	Step_PWM_SetCompare_Y(5.0);
	while (1)
	{
//		LED1_ON();
//		Delay_ms(500);
//		LED1_OFF();
//		Delay_ms(500);		

	}
}


void Motor_X_draw_rs_condition(void)
{
    // 当前总角度（度）= 象限起始角 + 象限内已过角度
    double angle_deg = (stage - 1) * 90.0 + (W * Count / 1000.0);
    double angle_rad = angle_deg * PI / 180.0;
    double omega_rad = W * PI / 180.0;                 // 角速度（弧度/秒）
    
    // X方向速度（单位/秒），假设电机每转对应平台移动1单位长度
    double vx = -circle_R * omega_rad * sin(angle_rad);
    
    // 根据速度符号设置方向引脚
    if (vx >= 0)
        GPIO_SetBits(GPIOA, GPIO_Pin_5);   // X正方向
    else
        GPIO_ResetBits(GPIOA, GPIO_Pin_5); // X负方向
    
    // 取速度绝对值用于PWM频率计算
    Motor_X_Speed = fabs(vx);
    
    // 速度下限保护（避免频率过高导致计数器溢出）
    if (Motor_X_Speed < 0.01) Motor_X_Speed = 0.01;
}



void Motor_Y_draw_rs_condition(void)
{
    double angle_deg = (stage - 1) * 90.0 + (W * Count / 1000.0);
    double angle_rad = angle_deg * PI / 180.0;
    double omega_rad = W * PI / 180.0;
    
    double vy = circle_R * omega_rad * cos(angle_rad);
    
    if (vy >= 0)
        GPIO_SetBits(GPIOA, GPIO_Pin_4);   // Y正方向
    else
        GPIO_ResetBits(GPIOA, GPIO_Pin_4); // Y负方向
    
    Motor_Y_Speed = fabs(vy);
    if (Motor_Y_Speed < 0.01) Motor_Y_Speed = 0.01;
}

void TIM1_UP_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
    {
        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  //1ms
        
        if (stage < 5)
        {
            Count++;
            
            Motor_X_draw_rs_condition();    // 计算X速度并设方向
            Motor_Y_draw_rs_condition();    // 计算Y速度并设方向
            
            // 设置PWM频率（步进电机脉冲）
            Step_PWM_SetCompare_X(Motor_X_Speed);
            Step_PWM_SetCompare_Y(Motor_Y_Speed);
            
            // 象限切换
            if (Count == one_four_t)
            {
                stage++;
                Count = 0;
            }
        }
        else
        {
            // 停止电机（释放使能或停止脉冲）
//            GPIO_ResetBits(GPIOA, GPIO_Pin_6);
//            GPIO_ResetBits(GPIOA, GPIO_Pin_7);
//            PWM_SetCompare3(0);
//            PWM_SetCompare32(0);
			Count++;
            Motor_X_draw_rs_condition();    // 计算X速度并设方向
            Motor_Y_draw_rs_condition();    // 计算Y速度并设方向
            
            // 设置PWM频率（步进电机脉冲）
            Step_PWM_SetCompare_X(Motor_X_Speed);
            Step_PWM_SetCompare_Y(Motor_Y_Speed);
            
            // 象限切换
            if (Count == one_four_t)
            {
                stage++;
                Count = 0;
            }			
        }
    }
}
